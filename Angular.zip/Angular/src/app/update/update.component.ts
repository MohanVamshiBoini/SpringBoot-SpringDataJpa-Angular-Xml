import { Component, OnInit } from '@angular/core';
import { HttpClientService, Employee } from '../service/httpclient.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  user: Employee = new Employee(0,"","");

  constructor(
    private httpClientService: HttpClientService
  ) { }

  ngOnInit() {
  }

  updateEmployee(): void {
    console.log(this.user.id);
    this.httpClientService.updateEmployee(this.user)
        .subscribe( data => {
          alert("Employee updated successfully.");
        });

  };

}